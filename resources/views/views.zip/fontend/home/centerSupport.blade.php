<div class="box_trungtam">
            <div class="box_trungtam_title">
              <label></label>
            </div>
            <aside style="padding-left:100px">
              <ul>

                            <li class="fl_w280">
                  <figure><img src="{{Asset($website['icon_mua_hang_tu_xa'])}}" alt="Mua hàng từ xa"></figure>
                  <label class="fl_bold fl_top5 fl_upercase fl_size13">Mua hàng từ xa</label>
                   <big class="fl_top5"><span>{{$website['sdt_mua_hang_tu_xa']}}</span><br>{{$website['email_mua_hang_tu_xa']}}</big> </li>
                            <li class="fl_w280">
                  <figure><img src="{{Asset($website['icon_trung_tam_bao_hanh'])}}" alt="Trung tâm bảo hành"></figure>
                  <label class="fl_bold fl_top5 fl_upercase fl_size13">Trung tâm bảo hành</label>
                   <big class="fl_top5"><span>{{$website['sdt_trung_tam_bh']}}</span><br>{{$website['email_trung_tam_bao_hanh']}}</big> </li>
                            <li class="fl_w280">
                  <figure><img src="{{Asset($website['icon_dai_ly'])}}" alt="Đại lý, buôn bán"></figure>
                  <label class="fl_bold fl_top5 fl_upercase fl_size13">Đại lý, buôn bán</label>
                   <big class="fl_top5"><span>{{$website['sdt_dai_ly']}}</span><br>{{$website['email_dai_ly']}}</big> </li>
                
                
              </ul>
            </aside>
        </div>