 <link rel="canonical" href='/' />
  <link rel="alternate" media="handheld" href='/' />
  <link href="{{Asset('')}}public/kingtech/css/cp/font-awesome/font-awesome.min.css" rel="stylesheet" type="text/css">
 
  <script src="{{Asset('')}}public/kingtech/js/jquery-1.11.3.min.js" type="text/javascript"></script>
    <link href="{{Asset('')}}public/kingtech/css/cssWeb.css" rel="stylesheet" type="text/css">
    <!-- <link href="{{Asset('')}}public/kingtech/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"> -->
    <link href="{{Asset('')}}public/kingtech/flexslider/slick.css" rel="stylesheet" type="text/css" media="all">
    <link href="{{Asset('')}}public/kingtech/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css" />

<div class="box_pages">
        <div class="box_trungtam_title">
          <label>DANH SÁCH ĐẠI LÝ KINGTECH TRÊN TOÀN QUỐC</label>
        </div>
        <div class="box_daily">
          <div class="pages_daily">
            <div class="footer_daily fl_top10 fl_left">
              <div class="daily_title fl_bold fl_upercase">MIỀN BẮC</div>
              <ul>
                <aside> <b>LIÊN HỆ LÀM ĐẠI LÝ</b><br>
                  Mr Nhật: 0907.9988.38 <br>
                  Email: minhnhat@kingtech.com.vn.vn</aside>
                                  <li>
                    <label>- Đại lý KINGTECH tại TP. Hà Nội</label>
                    <big>
                                              <span> <strong> CS1:</strong> <code><a href="/dai-ly/2-dai-ly-dang-cap-digital-tai-ha-noi" title="Đại lý KINGTECH tại Hà Nội">35 Phan Phù Tiên, P. Cát Linh, Q. Đống Đa, Hà Nội</a></code>
                <p>0938.9988.37 - 0862788.788</p>
                </span>
                                          </big> </li>
                                  <li>
                    <label>- Đại lý KINGTECH tại TP. Hải Phòng</label>
                    <big>
                                          </big> </li>
                                  <li>
                    <label>- Đại lý KINGTECH tại TP. Bắc Ninh</label>
                    <big>
                                              <span> <strong> CS1:</strong> <code><a href="/dai-ly/4-dai-ly-dang-cap-digital-tai-bac-ninh" title="Đại lý KINGTECH tại Bắc Ninh">98 Chợ Niềm Xá ( gần cổng trường Đảng) TP. Bắc Ninh</a></code>
                <p>0938.9988.37 - 0862788.788</p>
                </span>
                                          </big> </li>
                                  <li>
                    <label>- Đại lý KINGTECH tại TP. Hải Dương</label>
                    <big>
                                              <span> <strong> CS1:</strong> <code><a href="/dai-ly/12-dai-ly-dang-cap-digital-tai-hai-duong" title="Đại lý KINGTECH tại Hải Dương">54 Ngọc Tuyền - Ngọc Châu - TP. Hải Dương</a></code>
                <p>0938.9988.37 - 0862788.788</p>
                </span>
                                          </big> </li>
                              </ul>
            </div>
            <div class="footer_daily fl_top10 fl_left">
              <div class="daily_title fl_bold fl_upercase">MIỀN Trung</div>
              <ul class="daily_1">
                <aside> <b>LIÊN HỆ LÀM ĐẠI LÝ</b><br>
                  Mr Nhật: 0907.9988.38 <br>
                  Email: minhnhat@kingtech.com.vn</aside>
                                  <li>
                    <label>- Đại lý KINGTECH tại TP. Đà Nẵng</label>
                    <big>
                                              <span> <strong> CS1:</strong> <code><a href="/dai-ly/20-dai-ly-dang-cap-digital-tai-da-nang" title="Đại lý KINGTECH tại Đà Nẵng">139 Hàm Nghi - TP. Đà Nẵng</a></code>
                <p>0938.9988.37 - 0862788.788</p>
                </span>
                                          </big> </li>
                                  <li>
                    <label>- Đại lý KINGTECH tại TP. Ninh Thuận</label>
                    <big>
                                              <span> <strong> CS1:</strong> <code><a href="/dai-ly/63-dai-ly-dang-cap-digital-tai-ninh-thuan" title="Đại lý KINGTECH tại Ninh Thuận">115/12 Trần Qúy Cáp, KP.5, P. Mỹ Đông, TP.Tháp Chàm,Tỉnh Ninh Thuận</a></code>
                <p>0938.9988.37 - 0862788.788</p>
                </span>
                                          </big> </li>
                                  <li>
                    <label>- Đại lý KINGTECH tại TP. Gia Lai</label>
                    <big>
                                              <span> <strong> CS1:</strong> <code><a href="/dai-ly/24-dai-ly-dang-cap-digital-tai-gia-lai" title="Đại lý KINGTECH tại Gia Lai">28-30-32 Nguyễn Trãi, Tp. Pleiku, Tỉnh Gia Lai</a></code>
                <p>0938.9988.37 - 0862788.788</p>
                </span>
                                          </big> </li>
                                  <li>
                    <label>- Đại lý KINGTECH tại TP. Khánh Hòa</label>
                    <big>
                                              <span> <strong> CS1:</strong> <code><a href="/dai-ly/21-dai-ly-dang-cap-digital-tai-khanh-hoa" title="Đại lý KINGTECH tại Khánh Hòa">44 Đinh Tiên Hoàng - TP.Nha Trang</a></code>
                <p>0938.9988.37 - 0862788.788</p>
                </span>
                                              <span> <strong> CS2:</strong> <code><a href="/dai-ly/22-dai-ly-dang-cap-digital-tai-khanh-hoa" title="Đại lý KINGTECH tại Khánh Hòa">88 Lý Thánh Tôn - TP.Nha Trang</a></code>
                <p>0938.9988.37 - 0862788.788</p>
                </span>
                                          </big> </li>
                              </ul>
            </div>
            <div class="footer_daily fl_top10 fl_left">
              <div class="daily_title fl_bold fl_upercase">MIỀN Nam</div>
              <ul>
                <aside> <b>LIÊN HỆ LÀM ĐẠI LÝ</b><br>
                  Mr Nhật: 0907.9988.38 <br>
                  Email: minhnhat@kingtech.com.vn</aside>
                                  <li>
                    <label>- Đại lý KINGTECH tại TP. Hồ Chí Minh</label>
                    <big>
                                              <span> <strong> CS1:</strong> <code><a href="/dai-ly/53-dai-ly-dang-cap-digital-tai-tphcm" title="Đại lý KINGTECH tại TP.HCM">164 Nguyễn Phúc Nguyên- P.9- Q.3- HCM</a></code>
                <p>0862.788.788 - 0907.9988.38</p>
                </span>
                                              <span> <strong> CS2:</strong> <code><a href="/dai-ly/78-dang-cap-digital-tai-go-vap" title="KINGTECH tại Gò Vấp">164 Nguyễn Văn Lượng, Q. Gò Vấp, TP. HCM</a></code>
                <p>0822.61.3333- Hotline: 09091.2222.8</p>
                </span>
                                              <span> <strong> CS3:</strong> <code><a href="/dai-ly/57-dai-ly-dang-cap-digital-tai-tphcm" title="Đại lý KINGTECH tại TP.HCM">66 Đặng Văn Bi,P. Bình Thọ, Q.Thủ Đức ( Gần Nhà Máy Vinamilk)</a></code>
                <p>0909.270.569 - 090.2626.507</p>
                </span>
                                              <span> <strong> CS4:</strong> <code><a href="/dai-ly/55-dai-ly-dang-cap-digital-tai-tphcm" title="Đại lý KINGTECH tại TP.HCM">887 Lũy Bán Bích- P.Tân Thành - Q.Tân Phú</a></code>
                <p>0938.9988.37 - 0862788.788</p>
                </span>
                                          </big> </li>
                                  <li>
                    <label>- Đại lý KINGTECH tại TP. Bình Dương</label>
                    <big>
                                              <span> <strong> CS1:</strong> <code><a href="/dai-ly/39-dai-ly-dang-cap-digital-tai-binh-duong" title="Đại lý KINGTECH tại Bình Dương">280 Nguyễn Trãi- P.Lái Thiêu- Thuận An- Bình Dương</a></code>
                <p>0939.116.811 - 0966.39.6000</p>
                </span>
                                              <span> <strong> CS2:</strong> <code><a href="/dai-ly/67-dai-ly-dang-cap-digital-tai-binh-duong" title="Đại lý KINGTECH tại Bình Dương">923 Cách Mạng Tháng 8,P.Chánh Nghĩa,TP.Thủ Dầu Một,Bình Dương</a></code>
                <p>0938.9988.37 - 0862788.788</p>
                </span>
                                          </big> </li>
                                  <li>
                    <label>- Đại lý KINGTECH tại TP. Vũng Tàu</label>
                    <big>
                                              <span> <strong> CS1:</strong> <code><a href="/dai-ly/29-dai-ly-dang-cap-digital-tai-vung-tau" title="Đại lý KINGTECH tại Vũng Tàu">50A1 Nam kỳ khởi nghĩa - P. Thắng Tam - Tp. Vũng Tàu</a></code>
                <p>0933.008.449 - 0914.008.449</p>
                </span>
                                          </big> </li>
                                  <li>
                    <label>- Đại lý KINGTECH tại TP. An Giang</label>
                    <big>
                                              <span> <strong> CS1:</strong> <code><a href="/dai-ly/35-dai-ly-dang-cap-digital-tai-an-giang" title="Đại lý KINGTECH tại An Giang">7U - Lê Lợi - Tx.Châu Đốc ( Đối diện Nhà Thờ Châu Đốc )</a></code>
                <p>0915441567</p>
                </span>
                                              <span> <strong> CS2:</strong> <code><a href="/dai-ly/68-dai-ly-dang-cap-digital-tai-an-giang" title="Đại lý KINGTECH tại An Giang">346 Tôn Đức Thắng, P. Vinh Mỹ, TP Châu Đốc, An Giang</a></code>
                <p>0938.9988.37 - 0862788.788</p>
                </span>
                                          </big> </li>
                                  <li>
                    <label>- Đại lý KINGTECH tại TP. Cần Thơ</label>
                    <big>
                                              <span> <strong> CS1:</strong> <code><a href="/dai-ly/38-dai-ly-dang-cap-digital-tai-can-tho" title="Đại lý KINGTECH tại Cần Thơ">41 Lý Tự Trọng - Q.Ninh Kiều - TP.Cần Thơ</a></code>
                <p>0938.9988.37 - 0862788.788</p>
                </span>
                                          </big> </li>
                                  <li>
                    <label>- Đại lý KINGTECH tại TP. Đồng Nai</label>
                    <big>
                                              <span> <strong> CS1:</strong> <code><a href="/dai-ly/41-dai-ly-dang-cap-digital-tai-dong-nai" title="Đại lý KINGTECH tại Đồng Nai">D394 - Tổ 8 - KP4 - P.Long Bình - Biên Hòa - Đồng Nai CTY TNHH THIẾT BỊ CÔNG NGHỆ HÀO HUÂN</a></code>
                <p>0938.9988.37 - 0862788.788</p>
                </span>
                                              <span> <strong> CS2:</strong> <code><a href="/dai-ly/77-dai-ly-dang-cap-digital-tai-long-khanh-dong-nai" title="Đại Lý KINGTECH Tại Long Khánh Đồng Nai">79 Trần Phú, P Phú Xuân An, Thị Xã Long Khánh, Đồng Nai</a></code>
                <p>0938.9988.37 - 0862788.788</p>
                </span>
                                          </big> </li>
                              </ul>
            </div>
          </div>
        </div>
      </div>